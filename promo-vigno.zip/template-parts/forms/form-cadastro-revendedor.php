<form method="POST" action="http://crm.i9me.com.br/proc.php" id="_form_13_" class="Form Form--style1 _form _form_13 _inline-form  _dark" novalidate>
 <input type="hidden" name="u" value="13" />
  <input type="hidden" name="f" value="13" />
  <input type="hidden" name="s" />
  <input type="hidden" name="c" value="0" />
  <input type="hidden" name="m" value="0" />
  <input type="hidden" name="act" value="sub" />
  <input type="hidden" name="v" value="2" />
  

  <div class="_form-content">

    <fieldset class="Form-fieldset">


<div class="Section-subSection Section-subSection--formBlock UserData u-paddingVertical u-paddingTop u-paddingBottom--inter">
  <div class="u-size16of24 u-maxSize--container u-alignCenterBox">
    <header class="Section-subSection-header">
      <h3 class="Section-subSection-header-title">INFORME OS SEUS DADOS</h3>
    </header>
    <div class="Section-subSection-content">
      <div class="Form-line u-flex u-flexDirectionRow u-flexSwitchReverse--mobile">  
        <div class="Form-row u-sizeFull u-marginBottom--inter--half u-overflowHidden u-positionRelative u-displayBlock is-animating">
            <label class="Form-label u-displayInlineBlock" for="email">EMAIL<span class="required">*</span></label>
            <i class="FigureIcon FigureIcon--envelope"></i>
             <input type="text" name="email" class="Form-input Form-input--text u-size24of24" placeholder="Digite seu e-mail" required/>


        </div>
      </div>
       
      <div class="Form-line u-flex u-flexDirectionRow u-flexSwitchReverse--mobile">
        <div class="Form-row u-size12of24 u-marginBottom--inter--half u-overflowHidden u-positionRelative u-displayBlock is-animating u-marginRight--inter">
            <label class="Form-label u-displayInlineBlock" for="firstname">NOME<span class="required">*</span></label>
            <i class="FigureIcon FigureIcon--user"></i>
            <input class="Form-input Form-input--text u-size24of24" type="text" id="firstname" name="firstname" placeholder="Digite seu nome" required="required">
        </div>
        <div class="Form-row u-size12of24 u-marginBottom--inter--half u-overflowHidden u-positionRelative u-displayBlock is-animating">
          <label class="Form-label u-displayInlineBlock" for="phone">TELEFONE / WHATSAPP<span class="required">*</span></label>
          <i class="FigureIcon FigureIcon--whatsapp"></i>
           <input type="text" name="phone" class="Form-input Form-input--text u-size24of24" placeholder="Digite o seu número" required/>
        </div>
    </div>
  </div><!-- .Section-subSection-content -->
</div>
</div><!-- .Section-subSection--formBlock -->

  <div class="Section-subSection Section-subSection--formBlock Segmentos u-paddingVertical u-paddingHorizontal--inter">
    <div class="u-sizeFull u-maxSize--container u-alignCenterBox">
    <header class="Section-subSection-header">
      <h3 class="Section-subSection-header-title">INFORME OS SEUS SEGMENTOS</h3>
    </header>
    <div class="Section-subSection-content u-displayFlex u-flexWrapWrap u-flexJustifyContentCenter">
      <input type="hidden" name="field[11][]" value="~|">
      <div class="_row _checkbox-radio u-displayFlex u-marginRight--inter is-animating">
        <label for="field_11Moda Feminina" class="u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter u-alignCenter u-isActionable">
          <input id="field_11Moda Feminina" type="checkbox" name="field[11][]" value="Moda Feminina">
          <i class="FigureIcon FigureIcon--vestido--color2 u-displayFlex u-marginBottom--inter--half u-marginTop--inter--half"></i>
          <span>Moda Feminina</span>
        </label>
      </div>
      <div class="_row _checkbox-radio u-displayFlex u-marginRight--inter is-animating">
        <label for="field_11Moda Masculina" class="u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter u-alignCenter u-isActionable">
        <input id="field_11Moda Masculina" type="checkbox" name="field[11][]" value="Moda Masculina"   >
        <i class="FigureIcon FigureIcon--blusaGravata--color2 u-displayFlex u-marginBottom--inter--half u-marginTop--inter--half"></i>
        <span>
            Moda Masculina         
        </span>
         </label>
      </div>
      <div class="_row _checkbox-radio u-displayFlex u-marginRight--inter is-animating">
        <label for="field_11Moda Infantil" class="u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter u-alignCenter u-isActionable">
        <input id="field_11Moda Infantil" type="checkbox" name="field[11][]" value="Moda Infantil"   >
        <i class="FigureIcon FigureIcon--infantil--color2 u-displayFlex u-marginBottom--inter--half u-marginTop--inter--half"></i>
        <span>
            Moda Infantil
        </span>
        </label>
      </div>
      <div class="_row _checkbox-radio u-displayFlex u-marginRight--inter is-animating">
        <label for="field_11Jeanswear" class="u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter u-alignCenter u-isActionable">
        <input id="field_11Jeanswear" type="checkbox" name="field[11][]" value="Jeanswear"   >
        <i class="FigureIcon FigureIcon--jeans--color2 u-displayFlex u-marginBottom--inter--half u-marginTop--inter--half"></i>
        <span>
            Jeans
        </span>
        </label>
      </div>
      <div class="_row _checkbox-radio u-displayFlex u-marginRight--inter is-animating">
        <label for="field_11Moda Íntima" class="u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter u-alignCenter u-isActionable">
        <input id="field_11Moda Íntima" type="checkbox" name="field[11][]" value="Moda Íntima"   >
        <i class="FigureIcon FigureIcon--lingerie--color2 u-displayFlex u-marginBottom--inter--half u-marginTop--inter--half"></i>
        <span>
            Moda Íntima
        </span>
        </label>
      </div>
      <div class="_row _checkbox-radio u-displayFlex u-marginRight--inter is-animating">
         <label for="field_11Moda Plus Size" class="u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter u-alignCenter u-isActionable">
        <input id="field_11Moda Plus Size" type="checkbox" name="field[11][]" value="Moda Plus Size"   >
        <i class="FigureIcon FigureIcon--plusSize--color2 u-displayFlex u-marginBottom--inter--half u-marginTop--inter--half"></i>
        <span>
            Moda Plus Size
        </span>
        </label>
      </div>
      <div class="_row _checkbox-radio is-animating u-marginRight--inter">
        <label for="field_11field_11Bolsas e Calçados" class="u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter u-alignCenter u-isActionable">
          <input id="field_11field_11Bolsas e Calçados" type="checkbox" name="field[11][]" value="Bolsas e Calçados"   >
          <i class="FigureIcon FigureIcon--calcado--color2 u-displayFlex u-marginBottom--inter--half u-marginTop--inter--half"></i>
          <span>
            Bolsas e Calçados
          </span>
        </label>
      </div>
      <div class="_row _checkbox-radio is-animating u-marginRight--inter">
        <label for="field_11Jóias e Acessórios" class="u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter u-alignCenter u-isActionable">
          <input id="field_11Jóias e Acessórios" type="checkbox" name="field[11][]" value="Jóias e Acessórios"   >
          <i class="FigureIcon FigureIcon--oculos--color2 u-displayFlex u-marginBottom--inter--half u-marginTop--inter--half"></i>
          <span>
            Jóias e Acessórios
          </span>
        </label>
      </div>


       <div class="_row _checkbox-radio is-animating u-marginRight--inter">
        <label for="field_11Moda Praia" class="u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter u-alignCenter u-isActionable">
          <input id="field_11Moda Praia" type="checkbox" name="field[11][]" value="Moda Praia"   >
          <i class="FigureIcon FigureIcon--bikini--color2 u-displayFlex u-marginBottom--inter--half u-marginTop--inter--half"></i>
          <span>
            Moda Praia
          </span>
        </label>
      </div>

      <div class="_row _checkbox-radio is-animating">
        <label for="field_11Outras Opções" class="u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter u-alignCenter u-isActionable">
          <input id="field_11Outras Opções" type="checkbox" name="field[11][]" value="Outras Opções"   >
          <i class="FigureIcon FigureIcon--cabide--color2 u-displayFlex u-marginBottom--inter--half u-marginTop--inter--half"></i>
          <span>
            Outras Opções
          </span>
        </label>
      </div>
    </div><!-- .Section-subSection-content -->
  </div>
  </div><!-- .Section-subSection--formBlock -->

  <div class="Section-subSection Section-subSection--formBlock UserData u-paddingVertical u-paddingHorizontal--inter">
    <div class="u-size16of24 u-maxSize--container u-alignCenterBox">
    <header class="Section-subSection-header">
      <h3 class="Section-subSection-header-title">INFORMAÇÕES COMPLEMENTARES</h3>
    </header>
    <div class="Section-subSection-content">



      <div class="Form-line u-flex u-flexDirectionRow u-flexSwitchReverse--mobile">  
        <div class="Form-row u-sizeFull u-marginBottom--inter--half u-overflowHidden u-positionRelative u-displayBlock is-animating">
            <label class="Form-label u-displayInlineBlock">O QUE VOCÊ GOSTARIA DE ENCONTRAR AQUI NO ROUPA EM ATACADO?</label>
             <textarea name="field[12]" class="Form-input Form-input--textarea u-size24of24" placeholder="" rows="5"></textarea>
        </div>
      </div>

    </div><!-- .Section-subSection-content -->
  </div>
  </div><!-- .Section-subSection--formBlock -->

  <div class="Section-subSection Section-subSection--formBlock UserData u-paddingVertical u-paddingTop--inter u-paddingBottom">
    <div class="u-size16of24 u-maxSize--container u-alignCenterBox">
    
    <div class="Section-subSection-content">

     <div class="_form_element _field10 _full_width " >
      <input type="hidden" name="field[10]" value="" />
    </div>
    <div class="_button-wrapper _full_width u-alignCenter">
      <p class="form-row u-marginBottom--inter--half LegalText">
        Você está prestes a realizar uma conexão exclusiva com <strong>fabricantes de roupas</strong> de todo o Brasil. Por favor, concorde com os nossos <a href="javascript:LightboxCall('termos-e-condicoes');"><strong>Termos e Condições</strong></a>.
      </p>
      <p class="u-marginBottom--inter LegalText _row _checkbox-radio">
         <input type="hidden" name="field[13][]" value="~|">
            <input id="field_13Eu concordo" type="checkbox" name="field[13][]" value="Eu concordo"   required>
            
              <label for="field_13Eu concordo" class="u-positionRelative">
                <strong>Eu concordo</strong><span class="required">*</span>
              </label>
      </p>
      <input type="submit" id="_form_13_submit" class="Form-input Form-input--submit Button u-displayInlineBlock is-animating u-borderRadius5 Button--mediumSize hover" value="CONCLUIR" />
    </div>
    <div class="_clear-element">
    </div>


    </div><!-- .Section-subSection-content -->
  </div>
  </div><!-- .Section-subSection--formBlock -->

</div><!-- ._form-content -->

<div class="_form-thank-you u-positionRelative u-size16of24 u-maxSize--container u-alignCenterBox u-paddingHorizontal--vrt" style="display:none;"></div>

</fieldset>

</form>
<script type="text/javascript">
window.cfields = {"11":"segmentos_de_moda","12":"observaes","13":"termos_e_condies","10":"origem"};
window._show_thank_you = function(id, message, trackcmp_url) {
  var form = document.getElementById('_form_' + id + '_'), thank_you = form.querySelector('._form-thank-you');
  form.querySelector('._form-content').style.display = 'none';
  thank_you.innerHTML = message;
  thank_you.style.display = 'block';
  if (typeof(trackcmp_url) != 'undefined' && trackcmp_url) {
    // Site tracking URL to use after inline form submission.
    _load_script(trackcmp_url);
  }
  if (typeof window._form_callback !== 'undefined') window._form_callback(id);
};
window._show_error = function(id, message, html) {
  var form = document.getElementById('_form_' + id + '_'), err = document.createElement('div'), button = form.querySelector('button'), old_error = form.querySelector('._form_error');
  if (old_error) old_error.parentNode.removeChild(old_error);
  err.innerHTML = message;
  err.className = '_error-inner _form_error _no_arrow';
  var wrapper = document.createElement('div');
  wrapper.className = '_form-inner';
  wrapper.appendChild(err);
  button.parentNode.insertBefore(wrapper, button);
  document.querySelector('[id^="_form"][id$="_submit"]').disabled = false;
  if (html) {
    var div = document.createElement('div');
    div.className = '_error-html';
    div.innerHTML = html;
    err.appendChild(div);
  }
};
window._load_script = function(url, callback) {
    var head = document.querySelector('head'), script = document.createElement('script'), r = false;
    script.type = 'text/javascript';
    script.charset = 'utf-8';
    script.src = url;
    if (callback) {
      script.onload = script.onreadystatechange = function() {
      if (!r && (!this.readyState || this.readyState == 'complete')) {
        r = true;
        callback();
        }
      };
    }
    head.appendChild(script);
};
(function() {
  if (window.location.search.search("excludeform") !== -1) return false;
  var getCookie = function(name) {
    var match = document.cookie.match(new RegExp('(^|; )' + name + '=([^;]+)'));
    return match ? match[2] : null;
  }
  var setCookie = function(name, value) {
    var now = new Date();
    var time = now.getTime();
    var expireTime = time + 1000 * 60 * 60 * 24 * 365;
    now.setTime(expireTime);
    document.cookie = name + '=' + value + '; expires=' + now + ';path=/';
  }
      var addEvent = function(element, event, func) {
    if (element.addEventListener) {
      element.addEventListener(event, func);
    } else {
      var oldFunc = element['on' + event];
      element['on' + event] = function() {
        oldFunc.apply(this, arguments);
        func.apply(this, arguments);
      };
    }
  }
  var _removed = false;
  var form_to_submit = document.getElementById('_form_13_');
  var allInputs = form_to_submit.querySelectorAll('input, select, textarea'), tooltips = [], submitted = false;

  var getUrlParam = function(name) {
    var regexStr = '[\?&]' + name + '=([^&#]*)';
    var results = new RegExp(regexStr, 'i').exec(window.location.href);
    return results != undefined ? decodeURIComponent(results[1]) : false;
  };

  for (var i = 0; i < allInputs.length; i++) {
    var regexStr = "field\\[(\\d+)\\]";
    var results = new RegExp(regexStr).exec(allInputs[i].name);
    if (results != undefined) {
      allInputs[i].dataset.name = window.cfields[results[1]];
    } else {
      allInputs[i].dataset.name = allInputs[i].name;
    }
    var fieldVal = getUrlParam(allInputs[i].dataset.name);

    if (fieldVal) {
      if (allInputs[i].type == "radio" || allInputs[i].type == "checkbox") {
        if (allInputs[i].value == fieldVal) {
          allInputs[i].checked = true;
        }
      } else {
        allInputs[i].value = fieldVal;
      }
    }
  }

  var remove_tooltips = function() {
    for (var i = 0; i < tooltips.length; i++) {
      tooltips[i].tip.parentNode.removeChild(tooltips[i].tip);
    }
      tooltips = [];
  };
  var remove_tooltip = function(elem) {
    for (var i = 0; i < tooltips.length; i++) {
      if (tooltips[i].elem === elem) {
        tooltips[i].tip.parentNode.removeChild(tooltips[i].tip);
        tooltips.splice(i, 1);
        return;
      }
    }
  };
  var create_tooltip = function(elem, text) {
    var tooltip = document.createElement('div'), arrow = document.createElement('div'), inner = document.createElement('div'), new_tooltip = {};
    if (elem.type != 'radio' && elem.type != 'checkbox') {
      tooltip.className = '_error';
      arrow.className = '_error-arrow';
      inner.className = '_error-inner';
      inner.innerHTML = text;
      tooltip.appendChild(arrow);
      tooltip.appendChild(inner);
      elem.parentNode.appendChild(tooltip);
    } else {
      tooltip.className = '_error-inner _no_arrow';
      tooltip.innerHTML = text;
      elem.parentNode.insertBefore(tooltip, elem);
      new_tooltip.no_arrow = true;
    }
    new_tooltip.tip = tooltip;
    new_tooltip.elem = elem;
    tooltips.push(new_tooltip);
    return new_tooltip;
  };
  var resize_tooltip = function(tooltip) {
    var rect = tooltip.elem.getBoundingClientRect();
    var doc = document.documentElement, scrollPosition = rect.top - ((window.pageYOffset || doc.scrollTop)  - (doc.clientTop || 0));
    if (scrollPosition < 40) {
      tooltip.tip.className = tooltip.tip.className.replace(/ ?(_above|_below) ?/g, '') + ' _below';
    } else {
      tooltip.tip.className = tooltip.tip.className.replace(/ ?(_above|_below) ?/g, '') + ' _above';
    }
  };
  var resize_tooltips = function() {
    if (_removed) return;
    for (var i = 0; i < tooltips.length; i++) {
      if (!tooltips[i].no_arrow) resize_tooltip(tooltips[i]);
    }
  };
  var validate_field = function(elem, remove) {
    var tooltip = null, value = elem.value, no_error = true;
    remove ? remove_tooltip(elem) : false;
    if (elem.type != 'checkbox') elem.className = elem.className.replace(/ ?_has_error ?/g, '');
    if (elem.getAttribute('required') !== null) {
      if (elem.type == 'radio' || (elem.type == 'checkbox' && /any/.test(elem.className))) {
        var elems = form_to_submit.elements[elem.name];
        if (!(elems instanceof NodeList || elems instanceof HTMLCollection) || elems.length <= 1) {
          no_error = elem.checked;
        }
        else {
          no_error = false;
          for (var i = 0; i < elems.length; i++) {
            if (elems[i].checked) no_error = true;
          }
        }
        if (!no_error) {
          tooltip = create_tooltip(elem, "Por favor, selecione uma opção.");
        }
      } else if (elem.type =='checkbox') {
        var elems = form_to_submit.elements[elem.name], found = false, err = [];
        no_error = true;
        for (var i = 0; i < elems.length; i++) {
          if (elems[i].getAttribute('required') === null) continue;
          if (!found && elems[i] !== elem) return true;
          found = true;
          elems[i].className = elems[i].className.replace(/ ?_has_error ?/g, '');
          if (!elems[i].checked) {
            no_error = false;
            elems[i].className = elems[i].className + ' _has_error';
            err.push("Marcar %s é necessário".replace("%s", elems[i].value));
          }
        }
        if (!no_error) {
          tooltip = create_tooltip(elem, err.join('<br/>'));
        }
      } else if (elem.tagName == 'SELECT') {
        var selected = true;
        if (elem.multiple) {
          selected = false;
          for (var i = 0; i < elem.options.length; i++) {
            if (elem.options[i].selected) {
              selected = true;
              break;
            }
          }
        } else {
          for (var i = 0; i < elem.options.length; i++) {
            if (elem.options[i].selected && !elem.options[i].value) {
              selected = false;
            }
          }
        }
        if (!selected) {
          elem.className = elem.className + ' _has_error';
          no_error = false;
          tooltip = create_tooltip(elem, "Por favor, selecione uma opção.");
        }
      } else if (value === undefined || value === null || value === '') {
        elem.className = elem.className + ' _has_error';
        no_error = false;
        tooltip = create_tooltip(elem, "Este campo é necessário.");
      }
    }
    if (no_error && elem.name == 'email') {
      if (!value.match(/^[\+_a-z0-9-'&=]+(\.[\+_a-z0-9-']+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i)) {
        elem.className = elem.className + ' _has_error';
        no_error = false;
        tooltip = create_tooltip(elem, "Digite um e-mail válido");
      }
    }
    if (no_error && /date_field/.test(elem.className)) {
      if (!value.match(/^\d\d\d\d-\d\d-\d\d$/)) {
        elem.className = elem.className + ' _has_error';
        no_error = false;
        tooltip = create_tooltip(elem, "Digite uma data válida.");
      }
    }
    tooltip ? resize_tooltip(tooltip) : false;
    return no_error;
  };
  var needs_validate = function(el) {
    return el.name == 'email' || el.getAttribute('required') !== null;
  };
  var validate_form = function(e) {
    var err = form_to_submit.querySelector('._form_error'), no_error = true;
    if (!submitted) {
      submitted = true;
      for (var i = 0, len = allInputs.length; i < len; i++) {
        var input = allInputs[i];
        if (needs_validate(input)) {
          if (input.type == 'text') {
            addEvent(input, 'blur', function() {
              this.value = this.value.trim();
              validate_field(this, true);
            });
            addEvent(input, 'input', function() {
              validate_field(this, true);
            });
          } else if (input.type == 'radio' || input.type == 'checkbox') {
            (function(el) {
              var radios = form_to_submit.elements[el.name];
              for (var i = 0; i < radios.length; i++) {
                addEvent(radios[i], 'click', function() {
                  validate_field(el, true);
                });
              }
            })(input);
          } else if (input.tagName == 'SELECT') {
            addEvent(input, 'change', function() {
              validate_field(this, true);
            });
          }
        }
      }
    }
    remove_tooltips();
    for (var i = 0, len = allInputs.length; i < len; i++) {
      var elem = allInputs[i];
      if (needs_validate(elem)) {
        if (elem.tagName.toLowerCase() !== "select") {
          elem.value = elem.value.trim();
        }
        validate_field(elem) ? true : no_error = false;
      }
    }
    if (!no_error && e) {
      e.preventDefault();
    }
    resize_tooltips();
    return no_error;
  };
  addEvent(window, 'resize', resize_tooltips);
  addEvent(window, 'scroll', resize_tooltips);
  window._old_serialize = null;
  if (typeof serialize !== 'undefined') window._old_serialize = window.serialize;
  _load_script("//d3rxaij56vjege.cloudfront.net/form-serialize/0.3/serialize.min.js", function() {
    window._form_serialize = window.serialize;
    if (window._old_serialize) window.serialize = window._old_serialize;
  });
  var form_submit = function(e) {
    e.preventDefault();
    if (validate_form()) {
      // use this trick to get the submit button & disable it using plain javascript
      document.querySelector('[id^="_form"][id$="_submit"]').disabled = true;
            var serialized = _form_serialize(document.getElementById('_form_13_'));
      var err = form_to_submit.querySelector('._form_error');
      err ? err.parentNode.removeChild(err) : false;
      _load_script('http://crm.i9me.com.br/proc.php?' + serialized + '&jsonp=true');
    }
    return false;
  };
  addEvent(form_to_submit, 'submit', form_submit);
})();

</script>