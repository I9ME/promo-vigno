<section class="Section Section--footerContent Section--style1 u-paddingVertical u-paddingBottom">
	
	<div class="u-maxSize--container u-alignCenterBox u-displayFlex u-flexDirectionColumn u-flexSwitchRow">
	
		<div class="Section-container u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter u-sizeFull">
			<header class="Section-header u-positionRelative u-displayFlex u-flexDirectionRow u-flexAlignItemsCenter u-flexJustifyContentCenter u-size12of24">
				<i class="FigureIcon FigureIcon--newsletter u-displayBlock"></i>
				<h2 class="Section-header-title u-marginLeft--inter--half--px"><strong>RECEBA</strong> AS NOSSAS PROMOÇÕES NO SEU <strong>E-MAIL</strong></h2>
			</header>
			<div class="Section-content u-marginTop--inter u-size12of24">
				<form class="Form Form--style3">
					<fieldset class="Form-fieldset">
						<div class="Form-line u-flex u-flexDirectionRow">
							<div class="Form-row Form-row--email u-sizeFull u-positionRelative u-displayBlock">
								<i class="u-icon u-icon--envelope">
									<svg class="iconEnvelope u-icon is-animating">
										<use xlink:href="#iconEnvelope"></use>
									</svg>
								</i>
								<input class="Form-input Form-input--text u-borderRadius5 Form-border--0 u-size24of24 u-boxShadow" placeholder="Digite o seu e-mail" type="text" name="email" />
								<input class="Form-input Form-input--submit FigureIcon--send is-animating hover" type="submit" value="" />
							</div>
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div> <!-- Max Size Container -->
</section>