<ul class="SocialMediaBar u-positionRelative u-displayFlex u-flexDirectionRow u-sizeFull u-flexJustifyContentCenter">
			
	<!-- <li class="SocialMediaBar-site u-displayFlex u-flexAlignItemsCenter">
		<a class="u-displayBlock LinkHover" href="http://www.pizzaVignoli.com.br" target="_blank">
			<i class="FigureIcon FigureIcon--a FigureIcon--site is-animating"></i>
			<i class="FigureIcon FigureIcon--b FigureIcon--site--hover is-animating"></i>
		</a>
	</li> -->
	<li class="SocialMediaBar-facebook u-displayFlex u-flexAlignItemsCenter u-marginVertical--inter--half">
		<a class="u-displayBlock LinkHover is-animating" href="https://www.facebook.com/vignolipizzaria/" target="_blank">
			<i class="FigureIcon FigureIcon--a FigureIcon--facebook is-animating"></i>
			<i class="FigureIcon FigureIcon--b FigureIcon--facebook--hover is-animating"></i>
		</a>
	</li>
	<li class="SocialMediaBar-instagram u-displayFlex u-flexAlignItemsCenter u-marginVertical--inter--half">
		<a class="u-displayBlock LinkHover is-animating" href="https://www.instagram.com/pizzavignoli/" target="_blank">
			<i class="FigureIcon FigureIcon--a FigureIcon--instagram is-animating"></i>
			<i class="FigureIcon FigureIcon--b FigureIcon--instagram--hover is-animating"></i>
		</a>
	</li>
	<li class="SocialMediaBar-Tripadvisor u-displayFlex u-flexAlignItemsCenter u-marginVertical--inter--half">
		<a class="u-displayBlock LinkHover is-animating" href="https://www.tripadvisor.com.br/Restaurant_Review-g303293-d1097556-Reviews-Vignoli_Fortaleza_Virgilio_Tavora-Fortaleza_State_of_Ceara.html" target="_blank">
			<i class="FigureIcon FigureIcon--a FigureIcon--Tripadvisor is-animating"></i>
			<i class="FigureIcon FigureIcon--b FigureIcon--Tripadvisor--hover is-animating"></i>
		</a>
	</li>

</ul>