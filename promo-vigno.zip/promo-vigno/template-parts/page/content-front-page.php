<?php
/**
 * Displays content for front page
 *
 * @package WordPress
 * @subpackage Skeleton
 * @since 1.0
 * @version 1.0
 */

?>
<article id="post-<?php the_ID(); ?>" >



</article><!-- #post-## -->
